package mine.project.ratelimiter;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RateLimiterApplicationTests {

	@Test
	void contextLoads() {
	}

}
